//
//  AppDelegate.h
//  MyNote
//
//  Created by sushan on 2022/12/18.
//  Copyright © 2022 SYSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

